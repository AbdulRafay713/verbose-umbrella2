# CameraToChat

A tiny Android app that opens the camera, lets you snap a photo, and shares it straight to any app (DeepSeek, browser, WhatsApp) via Android's share sheet.

## Build (no coding)

See BUILD_INSTRUCTIONS.md. Short version:

1. Create a public GitHub repo
2. Upload every file in this folder (keep the folder structure)
3. Make sure `.github/workflows/build.yml` is uploaded
4. Actions tab → Build APK → Run workflow
5. Download the APK from Artifacts
6. Install on your phone

## License

MIT
