# Build the APK — no coding required

Total time ~10 minutes. Free.

## 1. Create the repository

Go to https://github.com/new
- Repository name: camera-to-chat
- Public
- Do NOT add a README
- Click the green **Create repository**

## 2. Upload the files

On the empty repo page click **"uploading an existing file"**
(or **Add file → Upload files**).

Drag in EVERYTHING INSIDE this folder — not the folder itself:
- app/
- build.gradle
- settings.gradle
- gradle.properties
- .github/

IMPORTANT: `.github` is a hidden folder and drag-and-drop often skips it.
After uploading, open `.github/workflows/build.yml` in the repo to confirm it exists.
If it is missing, create it manually:
Add file → Create new file → filename `.github/workflows/build.yml`
→ paste the contents → Commit.

Then click **Commit changes**.

## 3. Run the build

- Click the **Actions** tab
- If a banner says workflows are disabled, click **"I understand my workflows, go ahead and enable them"**
- Click **Build APK** on the left → **Run workflow** → green **Run workflow**
- Wait ~5 minutes for a green checkmark

## 4. Download and install

- Click the finished run
- Scroll to **Artifacts** → download **CameraToChat-debug-apk.zip**
- Unzip → `app-debug.apk`
- Transfer to your phone and tap it to install
- Allow "Install unknown apps" when Android asks

## Troubleshooting

Build fails on wrapper: the workflow generates the wrapper automatically; make sure you uploaded the exact build.yml from this project.

Actions tab is empty: `.github/workflows/build.yml` did not upload. Create it manually as described in step 2.

APK won't install: Settings → Apps → Special access → Install unknown apps → allow your file manager / browser.
